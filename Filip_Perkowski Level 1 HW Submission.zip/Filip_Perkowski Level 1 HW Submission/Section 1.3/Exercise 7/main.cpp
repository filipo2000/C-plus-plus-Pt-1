
// Power n Program
//This program raises the base of a factor of 2 to the nth power

#include <stdio.h>
#include <math.h>


//The key here is: 2 to the power n(#of shifts) = Number we are multipying by with our base number

int main() {

	int base; //This variable will hold our base
	int exp; //This variable will hold the exponent


	//User input
	printf("Please enter a base number must be a factor of 2: ");
	scanf_s("%d", &base);

	printf("Now please enter a exponent that you'd like to multiply our base by: ");
	scanf_s("%d", &exp);

	//Taking the appropriate power of the base
	int multi = pow(base, exp);

	//Print statement
	printf("%d to the %dth power equals:  %d", base, exp, multi);


}

