
//Exercise 5 Section 1.3
//This program is designed to show the difference between --i and i-- through the use of a if logical statement

#include <stdio.h>


int main() {

	int i = 10; //This is our i variable
	int input;  //This variable holds the user's input; If 0 gets inputed by the user i-- will be initiated otherwise --i will

	//User Input
	printf("i equals 10; Now, if you want to test i-- enter 0. If you want to test --i enter 1: ");
	scanf_s("%d", &input);

	//if logical statement seperating the two cases based on user input
	if (input == 0) {
		printf("Using i--, i now equals: %d", i--); //Here we get 10 via i--
	}
	else {
		printf("Using --i, i now equals: %d", --i); //Here we get 9 via --i
	}

}

