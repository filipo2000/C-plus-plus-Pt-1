
//Exercise 4 Section 1.3
//Marriage Program which will output the user's martial status based on his input

#include <stdio.h>

//Variable which will hold the martial status inputed by the user
int married;

int main() {

	//User input
	printf("If you are not married please enter 0; Otherwise enter anything but 0: ");
	scanf_s("%d", &married);

	//?: operator usage
	married ? printf("You are married") : printf("You are not married");

}

