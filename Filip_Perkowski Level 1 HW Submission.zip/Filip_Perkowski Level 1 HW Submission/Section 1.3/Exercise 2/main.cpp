//Program which computes the area of a triangle

#include <stdio.h>

//Our 2 variables which will hold the dimensions of our triangle
int height;
int base;

int main() {

	//User input
	printf("Please enter a height dimension for our triangle: ");
	scanf_s("%d", &height);
	printf("Now please enter a base dimension for our triangle: ");
	scanf_s("%d", &base);
	
	//Print Statement
	printf("The area of our triangle is: %d ", (base * height / 2));

}
