
//Exercise 1 Section 1.3

#include <stdio.h>

//Comments should be consistent; Either use // for a one-line comment or a /**/ for a multi-line comment
//There can be any ambigous variable names
//Indents should be proper like below; Right after a brace({) there should be an indent
//Make sure all the rules are followed for all the Exercise problems



int main() {

	printf("My First C-Program\n");
	printf("is a fact!\n");
	printf("Good, isin't it?");

}

