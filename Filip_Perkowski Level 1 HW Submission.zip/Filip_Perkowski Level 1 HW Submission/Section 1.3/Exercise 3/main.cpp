
//Operators

#include <stdio.h>
int main()
{                         //Using PEMDAS, to solve all these equations
	int x;
	x = -3 + 4 * 5 - 6;
	printf("x=%d\n", x); //Output -> 11; Explanation: [4 * 5 -> 20 - 3 -> 17 - 6 -> 11]
	x = 3 + 4 % 5 - 6;
	printf("x=%d\n", x); //Output -> 1; Explanation: [4 mod 5 -> 4 + 3 -> 7 - 6 -> 1]
	x = -3 * 4 % -6 / 5;
	printf("x=%d\n", x); //Output -> 0; Explanation: [ -3 * 4 -> -12 mod -6 -> 0 / 5 = 0 ]
	x = (7 + 6) % 5 / 2;
	printf("x=%d\n", x); //Output -> 1; Explanation: [7 + 6 -> 13 mod 5 -> 3 / 2 -> 1.5 rounded down to 1]
	return 0;
}

