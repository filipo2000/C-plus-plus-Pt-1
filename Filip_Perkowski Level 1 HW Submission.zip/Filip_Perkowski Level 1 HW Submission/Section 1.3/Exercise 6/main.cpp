
//2 Places To The Right Shift Program

#include <stdio.h>

int num; //Our variable which will hold our user input


int main() {

	//User Input
	printf("Please enter a int value that you'd like to shift: ");
	scanf_s("%d", &num);


	//By definition the leftmost bit given indication as to whether the variable's value is positive or negative. If the leftmost bit is 0 then the value is positive. If 1 then the value is negative
	//Based off this fact we can use an if statement to check the sign of the inputted value whether it's negative or not
	//1 shifted = Arithmetic Shift; //0 shifted = Logical Shift

	if (num < 0) { //Value is negative aka leftmost bit is 1; Hence we have a arithmetic shift
		num = num >> 2;
		printf("Shifting aritmetically two places to the right we get: %d ", num);

	}
	else { //In any other case we have a logical shift
		num = num >> 2;
		printf("Shifting logically 2 places to the right we get: %d ", num);

	}





}

