
#include <stdio.h>

/* Assignment operators */
//Goal is to interpet the outputs in the program


int main()
{
	int x = 2;
	int y;
	int z;
	x *= 3 + 2; //This is the same as: x = x * (3 + 2)
	printf("x=%d\n", x); // Should output 10 based on the above fact
	x *= y = z = 4; //So x is now 10 from the above line; x = x * y; y is 4 since y = z and z= 4; so x = 40 since 10 * 4 equals 40
	printf("x=%d\n", x); //Should output 40
	x = y == z; // Here y is equal to z(both are 4 from above) so True is the value for x. Variable x is an int so True gets converted to 1;
	printf("x=%d\n", x); //Should output 1
	return 0;

}

