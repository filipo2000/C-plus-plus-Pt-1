
#include <stdio.h>

/* Conditional expressions */
//Goal is to interpret the outputs in the program


int main()
{

	int x = 1;
	int y = 1;
	int z = 1;
	x += y += x; //Same as x = x + y; y = y + x; Now going from right to left: y = 2 and x = 1 for the first expression; But then, x = 3; y = 2 for the second;
	printf("%d\n\n", (x < y) ? y : x); // From the above x is greater than y so the expression evaluates to false; So we print our x aka 3
	printf("%d\n", (x < y) ? x++ : y++); // Here x is greater than y so the expression evaluates to false and we execture y++ because it postfix it's still 2 and that's what should get printed out
	printf("%d\n", x); // This should print out 3 our x value
	printf("%d\n", y); // This should print our 3 our revised y value
	return 0;

}

