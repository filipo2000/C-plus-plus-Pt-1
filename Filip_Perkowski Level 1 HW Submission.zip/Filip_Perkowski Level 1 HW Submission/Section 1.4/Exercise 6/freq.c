#include <stdio.h>


//0 - 4 frequency program count from user input
//Using a switch statement construction
//A switch statement gets executed once; So it's not a loop type; It's similar to an if-elseif-else statement branch


//Variables which will hold the counts for numbers: 0 - 4
int num0;
int num1;
int num2;
int num3;
int num4;
int otherc;

//This is the char variable that will be iterated through user input and be tested in the switch statement each iteration of the while loop
char current;


//A break statement makes us exit the switch statement. However, in this problem we would still be within the while loop as the switch statement is within the body of the while loop

int main() {
	printf("Please enter any input enter CTRL + Z after your'e done:\n"); //Be careful with the spaces in the printf() statement
	
	while (((current = getchar()) != EOF) && (current != 4) && (current != 26)) {
		
		switch(current){
			case '0':
				num0++; 
				break;
			case '1':
				num1++;
				break;
			case '2':
				num2++;
				break;
			case '3':
				num3++;
				break;
			case '4':
				num4++;
				break;
			case '\n': //Accounts for disregarding the spaces/ENTER keyword
				break;
			default:
				otherc++;
				break;
		}
			



	}

//Now for out printf statements
	printf("Number 1 occurs: %d times\n", num1);
	printf("Number 2 occurs: %d times\n", num2);
	printf("Number 3 occurs: %d times\n", num3);
	printf("Number 4 occurs: %d times\n", num4);
	printf("All others occurs: %d times\n", otherc);

}