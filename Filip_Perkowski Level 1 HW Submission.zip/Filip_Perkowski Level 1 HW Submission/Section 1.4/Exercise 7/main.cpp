#include <stdio.h>


//Extension of the previous switch program
//Which includes a constraint on the count of 3 from user input

//Our variables which will hold the counts from: 0-4. Othernum will hold the count for all other numbers/characters
int num0;
int num1;
int num2;
int num3;
int num4;
int othernum;

//This is the char variable that will be iterated through our while loop and consequently be tested within the switch statement each iteration
char current;



int main() {
	printf("Please enter any input. Once your'e done please enter CTRL + D\n");
	while (((current = getchar()) != EOF) && (current != 4)){

		switch (current) {
			case '0':
				num0++;
				break;
			case '1':
				num1++;
				break;
			case '2':
				num2++;
				break;
			case '3':
				num3++;
				break;
			case '4':
				num4++;
				break;
			case '\n': //This makes the program not take into account the space(aka ENTER keyword when using it and doesn't associate it with the othernum variable
				break;
			default:
				othernum++;
				break;
		}

}

	printf("Number 0 occurs: %d times\n", num0);
	printf("Number 1 occurs: %d times\n", num1);
	printf("Number 2 occurs: %d times\n", num2);
	
	//Constraint on the frequency of 3 in our input
	if (num3 == 1) {
		printf("Number three appears 1 time\n");
	}
	else if (num3 == 2) {
		printf("Number three appears 2 times\n");
	}
	else {
		printf("Number three appears more than 2 times\n");
	}
	
	printf("Number 4 occurs: %d times\n", num4);
	printf("All other numbers occur: %d times\n", othernum);

}