//Section 1.4 Exercise 1
//This program is meant to output the: number of character, words and lines from user input using a while loop


#include <stdio.h>
#include <ctype.h>
#include <conio.h>

//Measuring variables(to count the number of: characters, lines, and words)
int charcount; 
int linecount;
int wordcount;

//Iterating variables through the loop; We have a current character and a previous which looks at the character behind the current one
char current; 
char previous;

int main() {

	printf("Please enter any input combination. Once your done please enter CTRL+D:\n"); //CTRL + Z works for me

	current = getchar();
	while (current != EOF && current != 4) { //As long as we dont reach the end of our file our we don't encounter CTRL + D by the user yet whose ACSII value is 4 from our user's input we are good to go; 
		current = getchar();
		
		if (current != '\n') {
			charcount++;
		}
	                                          //Each iteration reads the next character from the keyboard thanks to getchar()


	//Now using seperate if statements to check each char input from the keyboard by the user
		if (current == '\n') {
			linecount++;
		}
			

        if (!isspace(current) && isspace(previous)) {
			wordcount++;
		}


		previous = current;

	}

	//Now to test our code with printf statements
	printf("The number of chars in the user input is: %d \n", charcount);
	printf("The number of lines in our user input is: %d \n", linecount);
	printf("The number of words in our user input is: %d \n", wordcount);




}