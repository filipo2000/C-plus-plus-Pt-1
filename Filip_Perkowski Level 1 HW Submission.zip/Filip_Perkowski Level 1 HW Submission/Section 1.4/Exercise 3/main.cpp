//Switch Statement Version of previous 2 programs

#include <stdio.h>
#include <ctype.h> //This header file includes the isspace() function

//Measuring variables
int charcount;
int linecount;
int wordcount;

//Char variable that is going to be iterated through the loop
char current;


int main() {
	
	printf("Please print out a sequence of strokes followed by CTRL + D:\n");

	
	while (((current = getchar()) != EOF) && (current != 4)) { //This should be a similar if not the same condition as in the while loop exercise
		
		switch (current) {
			
		case '\n': //Aka ENTER keystroke
			linecount++;
			wordcount++;
			break;


		case ' ':
			wordcount++;
			charcount++;
			break;


		default:
			charcount++;
			break;



		}
		


	}

	//Print Statements
	printf("Number of characters is: %d \n", charcount);
	printf("Number of lines is: %d \n", linecount);
	printf("Number of words is: %d \n", wordcount);


}

