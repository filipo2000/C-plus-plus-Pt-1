#include <stdio.h>


//Celcius To Farenheit Conversion Problem
//This time using a for loop construction

double c; //C for celcius
double f; //F for farenheit
double multi = 1.8; // Variable which hold the 9/5


int main() {
	//Celcuis to Farenheit Conversion(From 1 to 19 Celcius) //This is our header text/comment
	for (; c < 20; c++) {
		f = (c * multi) + 32;
		printf("Temperature in Celcius is: %.1f", c);
		printf("\tCorresponding temperature in Farenheit is: %.1f\n", f);
	}

}