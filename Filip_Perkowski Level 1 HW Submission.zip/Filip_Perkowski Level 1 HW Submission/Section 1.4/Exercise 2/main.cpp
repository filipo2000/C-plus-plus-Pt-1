#include <stdio.h>
#include <ctype.h>

//Similar program to previous but know using a Do-While Loop 

//Measuring Variables
int charcount; 
int linecount;
int wordcount = 1;

//Current and previous characters to be iterated in our do-while loop
char current; 
char previous;



int main() { //One do iteration is done before the while loop is tested
	printf("Print any input combination. Once finished please enter CTRL + D:\n");
	current = getchar();
	do {
		
		if (current != '\n') {
			charcount++;
		}
		
		if (current == '\n') { //This part works fine
			linecount++;
	}
		
		if ((!isspace(current)) && (isspace(previous))) {
			wordcount++;
	}
	
		previous = current;
	
	}


	while(((current = getchar()) != EOF) && (current != 4));

//Now for our printf statements

	printf("Number of chars our user input is: %d\n ", charcount);
	printf("Number of lines in our user input is: %d\n ", linecount);
	printf("Number of words in our user input is: %d\n ", wordcount);

}


