#include <stdio.h>

//C to F conversion Program
//Must use a while loop


//Celcius and Farenheit Variable
double f; //F for farenheit
double c; //C for celcius
double multi = .5555555556; //Variable which holds the value (5/9)


int main() {
	
	//Celcius to Farenheit Conversion(From 0 to 300 Farenheit) //This is our header text
	while (f < 301) { //Using a while construction
		c = multi * (f - 32);
    //Print Statements
	printf("Temperature in Farenheit is: %.1f", f);
	printf("\tCorresponding temperature in Celcius is: %.1f\n", c);
	f += 20; //Increment f's value by 20 for each successful iteration
}




}