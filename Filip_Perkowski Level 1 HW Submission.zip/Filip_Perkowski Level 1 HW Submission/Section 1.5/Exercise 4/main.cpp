#include <stdio.h>

//printnumber() function program
//Where printnumber() is a recursive function


int input; //This variable holds user input; Aka number which the user would like to output out digit by digit


void printnumber(int m) {

	if (m / 10) {
		printnumber(m / 10); //This recursion works here succesfully; By recursing we are effectively making it so that we will start out with the first digit of the number provided via input

	}

	if (m < 0) {
		putchar('-'); //Putting a negative to signal that we are dealing with a negative argument
		m = (-m);

	}
		
	putchar('0'+ m % 10); //This prints out the digit followed by a tab
	putchar('\t');


}



int main() {
	
	//User Input
	printf("Please enter a number that you would like to output: ");
	scanf_s("%d", &input);
	printnumber(input);

}