#include <stdio.h>

//Minus() program

int first; //Variable which hold the first number
int second; //Variable which holds the second number


int minus(int one, int two ) {
	return one - two;
}



int main() {

	printf("Please enter a number: ");
	scanf_s("%d", &first);
	printf("Now please enter a number that you'd like to subtract the first number by: ");
	scanf_s("%d", &second);

	int resi = minus(first,second);

	printf("%d minus %d equals: %d", first, second, resi);

}