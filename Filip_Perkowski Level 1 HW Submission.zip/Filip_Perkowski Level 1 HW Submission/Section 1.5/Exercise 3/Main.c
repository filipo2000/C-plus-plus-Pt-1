
#include <stdio.h>
 //By having Print.c in our project, it now makes it possible to use the times() function in this source file
//There's no need to include the header files as the files are already within the project



int input; //This variable will hold the user input

int main() {

    //User Input
	printf("Please enter a number that you'd like to double: ");
	scanf_s("%d", &input);

	int result = print(input); //This variable will hold the return value from calling the print() function with argument input
	printf("%d doubled equals: %d ", input, result);

	


}