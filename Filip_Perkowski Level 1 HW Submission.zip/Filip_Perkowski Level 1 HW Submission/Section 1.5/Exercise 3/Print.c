#include <stdio.h>


//This is our print function whose role is to return double of the argument that it's given
int print(int a) {
	return a * 2;
}