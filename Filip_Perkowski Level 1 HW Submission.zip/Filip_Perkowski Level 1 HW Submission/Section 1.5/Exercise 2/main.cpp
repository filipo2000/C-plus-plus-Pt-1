#include <stdio.h>

//Factorial Function
//Our factorial must be recursive; So essentially the function calls itself

int input; //This variable holds user input: aka the number that the user would like to find the factorial of

int factorial(int a) {
	if (a != 0) {
		return a * factorial(a - 1);
	}

}

int main() {
	
	//User input
	printf("Please enter a number that you'd like to find the factorial of: ");
	scanf_s("%d", &input);

	
	int result = factorial(input);
	printf("%d factorial equals: %d", input , result);

}